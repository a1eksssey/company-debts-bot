# ==================== НАСТРОЙКИ ====================

# 1. ТОКЕН ВАШЕГО TELEGRAM БОТА (от @BotFather)
TELEGRAM_TOKEN = "8290888256:AAELjPOMsOt8F_B59RnEuX5YgAzmZB-Pqm0"

# 2. API-КЛЮЧ GOOGLE (который вы только что получили)
GOOGLE_API_KEY = "AIzaSyD0cn-AUn1GENBIZoZCkg1vdwiIpbdwBLQ"

# 3. ID ВАШЕЙ GOOGLE ТАБЛИЦЫ (из ссылки)
SPREADSHEET_ID = "19iUX_rF9jpsDv9p5V_nj9dapOO6zUR5GDzy9o5GGoI8"

# 4. ID АДМИНИСТРАТОРОВ (Telegram ID через запятую)
ADMIN_IDS = [283883536, 222222222]

# 5. НАСТРОЙКИ УВЕДОМЛЕНИЙ
ENABLE_NOTIFICATIONS = True
ENABLE_LOGGING = True
NOTIFICATION_HOUR = 9

# ==================== ТЕХНИЧЕСКИЕ ====================
# Не меняйте эти настройки
GOOGLE_SCOPES = ['https://www.googleapis.com/auth/spreadsheets']